@echo off
title Starting FlashWire...
cd /d "%~dp0bin\Release"
start "" "FlashWire.exe"
exit
